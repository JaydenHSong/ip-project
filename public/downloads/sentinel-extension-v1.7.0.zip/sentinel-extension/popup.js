import"./chunks/modulepreload-polyfill.js";import{C as K,I as W,V as R,a as Q,b as Z,W as J}from"./chunks/constants.js";const C="ext.locale";let k="en";const X={"common.sentinel":"Sentinel","common.cancel":"Cancel","common.settings":"Settings","loading.text":"Loading...","login.title":"Sentinel","login.desc":"Sign in with your Spigen Google account to report violations.","login.desc.expired":"Your session has expired. Please sign in again to continue.","login.btn":"Sign in with Google","login.btn.loading":"Signing in...","login.error":"Sign in failed","form.seller":"Seller","form.violation":"Violation Type","form.category.placeholder":"Select Category","form.violation.placeholder":"Select Violation Type","form.note.label":"Note (optional)","form.note.placeholder":"Describe the violation...","form.submit":"Submit Report","form.submit.loading":"Submitting...","form.screenshot.hint":"Screenshot will be captured automatically.","form.error.submit":"Submission failed. Please try again.","preview.title":"Report Preview","preview.label.asin":"ASIN","preview.label.product":"Product","preview.label.marketplace":"Marketplace","preview.label.category":"Category","preview.label.violation":"Violation","preview.label.note":"Note","preview.label.screenshot":"Screenshot","preview.screenshot.auto":"Auto-attached","preview.countdown":"Sending automatically...","sending.title":"Sending Report...","sending.desc":"You can close this popup safely.<br/>The report will be sent in the background.","success.title":"Report Submitted!","success.desc":"Your violation report has been submitted successfully. The team will review it shortly.","success.duplicate":"A similar report already exists for this listing. Your report has been recorded for reference.","success.view":"View in Sentinel","success.another":"Report Another","settings.title":"Settings","settings.language":"Language","settings.theme":"Theme","settings.theme.light":"Light","settings.theme.dark":"Dark","settings.bgfetch.title":"Background ASIN Fetch","settings.bgfetch.toggle":"Enable Background Fetch","settings.bgfetch.hint1":"Sentinel automatically looks up ASINs in the background when requested from the web dashboard. A new tab opens briefly (~3s), collects product info, and closes automatically.","settings.bgfetch.hint2":"Your existing Amazon session is used. No additional login required.","settings.bgfetch.hint3":"Background Fetch is enabled by default.","error.not_amazon.title":"Not an Amazon Page","error.not_amazon.desc":"Open an Amazon product page to report a violation.","error.not_product.title":"Not a Product Page","error.not_product.desc":"Navigate to an individual product page (with /dp/ in the URL). Search and category pages are not supported.","error.parse.title":"Could Not Read Page","error.parse.desc":"Failed to extract product data. Try refreshing the page.","error.no_tab.title":"No Active Tab","error.no_tab.desc":"Could not detect the current tab. Try clicking the extension icon again.","error.connection.title":"Connection Error","error.connection.desc":"Could not connect to the extension background. Try reloading the extension.","bgfetch.banner":"Background Fetch","cat.intellectual_property":"Intellectual Property","cat.variation":"Variation","cat.main_image":"Main Image","cat.wrong_category":"Wrong Category","cat.pre_announcement":"Pre-announcement Listing","cat.review_violation":"Review Violation"},ee={"common.sentinel":"센티널","common.cancel":"취소","common.settings":"설정","loading.text":"로딩 중...","login.title":"Sentinel","login.desc":"Spigen Google 계정으로 로그인하여 위반을 신고하세요.","login.desc.expired":"세션이 만료되었습니다. 다시 로그인해 주세요.","login.btn":"Google로 로그인","login.btn.loading":"로그인 중...","login.error":"로그인 실패","form.seller":"판매자","form.violation":"위반 유형","form.category.placeholder":"카테고리 선택","form.violation.placeholder":"위반 유형 선택","form.note.label":"메모 (선택)","form.note.placeholder":"위반 사항을 설명하세요...","form.submit":"신고서 제출","form.submit.loading":"제출 중...","form.screenshot.hint":"스크린샷이 자동으로 캡처됩니다.","form.error.submit":"제출에 실패했습니다. 다시 시도해 주세요.","preview.title":"신고 미리보기","preview.label.asin":"ASIN","preview.label.product":"상품","preview.label.marketplace":"마켓플레이스","preview.label.category":"카테고리","preview.label.violation":"위반","preview.label.note":"메모","preview.label.screenshot":"스크린샷","preview.screenshot.auto":"자동 첨부","preview.countdown":"자동으로 전송됩니다...","sending.title":"신고서 전송 중...","sending.desc":"이 팝업을 닫아도 안전합니다.<br/>신고서는 백그라운드에서 전송됩니다.","success.title":"신고 완료!","success.desc":"위반 신고서가 성공적으로 제출되었습니다. 팀에서 곧 검토할 예정입니다.","success.duplicate":"이 리스팅에 대해 유사한 신고서가 이미 존재합니다. 귀하의 신고서는 참고용으로 기록되었습니다.","success.view":"Sentinel에서 보기","success.another":"추가 신고","settings.title":"설정","settings.language":"언어","settings.theme":"테마","settings.theme.light":"라이트","settings.theme.dark":"다크","settings.bgfetch.title":"백그라운드 ASIN 조회","settings.bgfetch.toggle":"백그라운드 조회 활성화","settings.bgfetch.hint1":"Sentinel이 웹 대시보드에서 요청 시 백그라운드에서 자동으로 ASIN을 조회합니다. 새 탭이 잠시(~3초) 열리고 상품 정보를 수집한 후 자동으로 닫힙니다.","settings.bgfetch.hint2":"기존 Amazon 세션이 사용됩니다. 추가 로그인이 필요하지 않습니다.","settings.bgfetch.hint3":"백그라운드 조회는 기본적으로 활성화되어 있습니다.","error.not_amazon.title":"아마존 페이지가 아닙니다","error.not_amazon.desc":"위반을 신고하려면 아마존 상품 페이지를 열어주세요.","error.not_product.title":"상품 페이지가 아닙니다","error.not_product.desc":"URL에 /dp/가 포함된 개별 상품 페이지로 이동해 주세요. 검색/카테고리 페이지는 지원되지 않습니다.","error.parse.title":"페이지를 읽을 수 없습니다","error.parse.desc":"상품 데이터 추출에 실패했습니다. 페이지를 새로고침해 보세요.","error.no_tab.title":"활성 탭 없음","error.no_tab.desc":"현재 탭을 감지할 수 없습니다. 확장 프로그램 아이콘을 다시 클릭해 보세요.","error.connection.title":"연결 오류","error.connection.desc":"확장 프로그램 백그라운드에 연결할 수 없습니다. 확장 프로그램을 다시 로드해 보세요.","bgfetch.banner":"백그라운드 조회","cat.intellectual_property":"지식재산권","cat.variation":"베리에이션","cat.main_image":"메인 이미지","cat.wrong_category":"잘못된 카테고리","cat.pre_announcement":"사전 공지 리스팅","cat.review_violation":"리뷰 위반"},M={en:X,ko:ee},i=t=>M[k][t]??M.en[t]??t,S=()=>k,te=t=>{k=t,chrome.storage.local.set({[C]:t})},se=()=>new Promise(t=>{chrome.storage.local.get(C,e=>{const s=e[C];(s==="ko"||s==="en")&&(k=s),t()})}),O="ext.theme";let L="light";const F=()=>L,ne=t=>{L=t,chrome.storage.local.set({[O]:t}),G(t)},G=t=>{document.documentElement.setAttribute("data-theme",t)},ie=()=>new Promise(t=>{chrome.storage.local.get(O,e=>{const s=e[O];(s==="light"||s==="dark")&&(L=s),G(L),t()})}),oe=t=>{t.innerHTML=`
    <div class="status-message loading-view">
      <div class="loading-view__spinner"></div>
      <p class="status-message__desc">${i("loading.text")}</p>
    </div>
  `},re=`
  <svg class="login-logo" viewBox="0 0 24.8 28" fill="var(--accent)" xmlns="http://www.w3.org/2000/svg">
    <path d="M14,0c2.6,0,4.6,2.1,4.6,4.7S16.5,9.3,14,9.3c-2.6,0-4.7,2.1-4.7,4.7s2,4.8,4.7,4.8s4.6,2.1,4.6,4.6c0,2.6-2.1,4.6-4.6,4.6c-2.6,0-4.7-2.1-4.7-4.6c0-2.6-2.1-4.6-4.6-4.6l0,0c-2.6,0-4.6-2.1-4.6-4.7s2.1-4.6,4.7-4.6l0,0c2.6,0,4.6-2.1,4.6-4.7C9.3,2.1,11.4,0,14,0z"/>
    <path d="M21,10.2c2.1,0,3.8,1.7,3.8,3.7c0,2.1-1.7,3.8-3.8,3.8s-3.7-1.7-3.7-3.8C17.2,11.9,18.9,10.2,21,10.2z"/>
  </svg>
`,P=`
  <svg width="18" height="18" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
    <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 01-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#4285F4"/>
    <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.26c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z" fill="#34A853"/>
    <path d="M3.964 10.71A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.042l3.007-2.332z" fill="#FBBC05"/>
    <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335"/>
  </svg>
`,z=(t,e,s)=>{const n=i(s==="session_expired"?"login.desc.expired":"login.desc");t.innerHTML=`
    <div class="login-container">
      ${re}
      <h1 class="login-title">${i("login.title")}</h1>
      <p class="login-desc">${n}</p>
      <button id="btn-google-login" class="btn btn--ghost login-btn">
        ${P}
        ${i("login.btn")}
      </button>
      <div id="login-error" class="error-text hidden"></div>
    </div>
  `;const r=t.querySelector("#btn-google-login"),a=t.querySelector("#login-error");r.addEventListener("click",async()=>{r.disabled=!0,r.innerHTML=`<span class="spinner"></span> ${i("login.btn.loading")}`,a.classList.add("hidden"),chrome.runtime.sendMessage({type:"SIGN_IN"},o=>{o!=null&&o.success?e():(a.textContent=(o==null?void 0:o.error)??i("login.error"),a.classList.remove("hidden"),r.disabled=!1,r.innerHTML=`${P} ${i("login.btn")}`)})})},ae=(t,e)=>{const s=S();t.innerHTML=`
    <div class="form-group">
      <label class="form-label form-label--required">${i("form.violation")}</label>
      <select id="select-category" class="form-select">
        <option value="">${i("form.category.placeholder")}</option>
        ${K.map(a=>`<option value="${a}">${i(`cat.${a}`)}</option>`).join("")}
      </select>
      <select id="select-violation" class="form-select hidden">
        <option value="">${i("form.violation.placeholder")}</option>
      </select>
    </div>
  `;const n=t.querySelector("#select-category"),r=t.querySelector("#select-violation");n.addEventListener("change",()=>{const a=n.value;if(!a){r.innerHTML=`<option value="">${i("form.violation.placeholder")}</option>`,r.classList.add("hidden"),e(null,null);return}if(a==="intellectual_property"){const o=u=>{const l=R[u];return s==="ko"?l.nameKo:l.nameEn};r.innerHTML=`
        <option value="">${i("form.violation.placeholder")}</option>
        ${W.map(u=>`<option value="${u}">${u} — ${o(u)}</option>`).join("")}
      `,r.classList.remove("hidden"),r.value="",e(null,a)}else r.classList.add("hidden"),e(null,a)}),r.addEventListener("change",()=>{const a=r.value,o=n.value;e(a||null,o||null)})},le=(t,e,s)=>{if(!e){t.innerHTML="",s({},!1);return}const n=Q[e];if(!n||n.fields.length===0){t.innerHTML="",s({},!0);return}const r=S(),a=l=>r==="ko"?l.labelKo:l.labelEn;t.innerHTML=n.fields.map(l=>`
      <div class="form-group">
        <label class="form-label${l.required?" form-label--required":""}">${a(l)}</label>
        <textarea
          id="field-${l.id}"
          class="form-textarea"
          rows="${l.rows}"
          maxlength="2000"
          data-field-id="${l.id}"
          data-required="${l.required}"
        ></textarea>
      </div>
    `).join("");const o={},u=()=>n.fields.filter(l=>l.required).every(l=>(o[l.id]??"").trim().length>0);n.fields.forEach(l=>{const m=t.querySelector(`#field-${l.id}`);o[l.id]="",m.addEventListener("input",()=>{o[l.id]=m.value,s({...o},u())})}),s({...o},u())},D=`
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
  </svg>
`,ce=(t,e)=>{t.innerHTML=`
    <button id="btn-submit" class="btn btn--primary" disabled>
      ${D}
      ${i("form.submit")}
    </button>
    <p class="hint-text">${i("form.screenshot.hint")}</p>
  `,t.querySelector("#btn-submit").addEventListener("click",e)},de=t=>{const e=document.querySelector("#btn-submit");e&&(e.disabled=!t)},q=t=>{const e=document.querySelector("#btn-submit");e&&(t?(e.disabled=!0,e.innerHTML=`<span class="spinner"></span> ${i("form.submit.loading")}`):(e.disabled=!1,e.innerHTML=`${D} ${i("form.submit")}`))},h=t=>{const e=document.createElement("div");return e.textContent=t,e.innerHTML},ge=(t,e,s)=>{const n={violationType:null,violationCategory:null,extraFields:{},requiredFieldsFilled:!1},r=h(e.marketplace);t.innerHTML=`
    <div class="popup-content">
      <div class="product-info">
        <span class="product-info__asin">${h(e.asin)}</span>
        <p class="product-info__title">${h(e.title)}</p>
        ${e.seller_name?`<span class="product-info__seller">${i("form.seller")}: ${h(e.seller_name)}</span>`:""}
        <span class="product-info__marketplace">${r}</span>
      </div>
      <div id="violation-selector"></div>
      <div id="dynamic-fields"></div>
      <div id="submit-area"></div>
      <div id="form-error" class="error-text hidden"></div>
    </div>
  `;const a=t.querySelector("#violation-selector"),o=t.querySelector("#dynamic-fields"),u=t.querySelector("#submit-area"),l=t.querySelector("#form-error"),m=()=>n.violationCategory?n.violationCategory==="intellectual_property"?n.violationType!==null:!0:!1,v=()=>{de(m()&&n.requiredFieldsFilled)},p=()=>n.violationCategory?n.violationCategory==="intellectual_property"?n.violationType:n.violationCategory:null,f=()=>{const b=p();le(o,b,(g,_)=>{n.extraFields=g,n.requiredFieldsFilled=_,v()})};ae(a,(b,g)=>{n.violationType=b,n.violationCategory=g,f(),v()}),ce(u,async()=>{if(!m()||!n.violationCategory)return;q(!0),l.classList.add("hidden");const b=await new Promise(w=>{chrome.runtime.sendMessage({type:"CAPTURE_SCREENSHOT"},w)}),g=b.success?b.data:"";q(!1);const _=n.violationCategory==="intellectual_property"?n.violationType:n.violationCategory,j=Object.entries(n.extraFields).filter(([,w])=>w.trim()).map(([w,Y])=>`[${w}]
${Y}`).join(`

`);s({pageData:e,violationType:_,violationCategory:n.violationCategory,note:j,screenshotBase64:g,extraFields:Object.keys(n.extraFields).length>0?n.extraFields:void 0})})},y=3,B=188.5,ue=(t,e,s,n)=>{const r=`cat.${e.violationCategory}`,a=e.violationCategory==="intellectual_property";let o;if(a&&e.violationType in R){const g=R[e.violationType],_=S()==="ko"?g.nameKo:g.nameEn;o=`${g.code} &mdash; ${h(_)}`}else o=Z[e.violationCategory]??e.violationCategory;const u=e.extraFields?Object.entries(e.extraFields).filter(([,g])=>g.trim()).map(([g,_])=>`
        <div class="preview-card__row">
          <span class="preview-card__label">${h(g)}</span>
          <span class="preview-card__value preview-card__value--note">${h(_)}</span>
        </div>`).join(""):"";t.innerHTML=`
    <div class="preview-container">
      <h2 class="preview-header">${i("preview.title")}</h2>

      <div class="preview-card">
        <div class="preview-card__row">
          <span class="preview-card__label">${i("preview.label.asin")}</span>
          <span class="preview-card__value preview-card__value--accent">${h(e.pageData.asin)}</span>
        </div>
        <div class="preview-card__row">
          <span class="preview-card__label">${i("preview.label.product")}</span>
          <span class="preview-card__value preview-card__value--title">${h(e.pageData.title)}</span>
        </div>
        <div class="preview-card__row">
          <span class="preview-card__label">${i("preview.label.marketplace")}</span>
          <span class="preview-card__value">${h(e.pageData.marketplace)}</span>
        </div>
        <div class="preview-card__row">
          <span class="preview-card__label">${i("preview.label.category")}</span>
          <span class="preview-card__value">${i(r)}</span>
        </div>
        ${a?`
        <div class="preview-card__row">
          <span class="preview-card__label">${i("preview.label.violation")}</span>
          <span class="preview-card__value">${o}</span>
        </div>
        `:""}
        ${u}
        <div class="preview-card__row">
          <span class="preview-card__label">${i("preview.label.screenshot")}</span>
          <span class="preview-card__value preview-card__value--muted">${i("preview.screenshot.auto")}</span>
        </div>
      </div>

      <div class="countdown-area">
        <svg class="countdown-ring" viewBox="0 0 64 64">
          <circle class="countdown-ring__bg" cx="32" cy="32" r="30" fill="none" stroke="var(--border)" stroke-width="3" />
          <circle id="countdown-circle" class="countdown-ring__circle" cx="32" cy="32" r="30" fill="none" stroke="var(--accent)" stroke-width="3"
            stroke-dasharray="${B}" stroke-dashoffset="0"
            stroke-linecap="round" />
          <text id="countdown-text" class="countdown-ring__text" x="32" y="36" text-anchor="middle" fill="var(--text-primary)" font-size="16" font-weight="600">${y}</text>
        </svg>
        <p class="countdown-label">${i("preview.countdown")}</p>
      </div>

      <button id="btn-preview-cancel" class="btn btn--ghost">${i("common.cancel")}</button>
    </div>
  `;const l=t.querySelector("#countdown-circle"),m=t.querySelector("#countdown-text"),v=t.querySelector("#btn-preview-cancel");let p=0,f=!1;chrome.runtime.sendMessage({type:"PREPARE_REPORT",payload:{page_data:e.pageData,violation_type:e.violationType,violation_category:e.violationCategory,note:e.note,screenshot_base64:e.screenshotBase64,extra_fields:e.extraFields}});const b=setInterval(()=>{if(f)return;p+=100;const g=p/(y*1e3);l.setAttribute("stroke-dashoffset",String(B*g));const _=Math.ceil((y*1e3-p)/1e3);m.textContent=String(_),p>=y*1e3&&(clearInterval(b),s())},100);v.addEventListener("click",()=>{f=!0,clearInterval(b);try{chrome.storage.session.remove("pending_report")}catch{}n()}),window.addEventListener("beforeunload",()=>{if(!f&&p<y*1e3)try{chrome.runtime.sendMessage({type:"CONFIRM_REPORT"})}catch{}})},ve=t=>{t.innerHTML=`
    <div class="status-message sending-view">
      <div class="sending-view__spinner"></div>
      <h2 class="status-message__title">${i("sending.title")}</h2>
      <p class="status-message__desc">${i("sending.desc")}</p>
    </div>
  `},pe=`
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>
`,me=(t,e,s=!1)=>{const n=`${J}/reports/${e}`;t.innerHTML=`
    <div class="status-message success-view">
      <div class="success-check success-check--animated">
        ${pe}
      </div>
      <h2 class="status-message__title">${i("success.title")}</h2>
      ${s?`
        <p class="status-message__desc status-message__desc--warn">
          ${i("success.duplicate")}
        </p>
      `:`
        <p class="status-message__desc">
          ${i("success.desc")}
        </p>
      `}
      <a href="${n}" target="_blank" rel="noopener" class="btn btn--ghost success-view__btn">
        ${i("success.view")}
      </a>
      <button id="btn-new-report" class="btn btn--primary success-view__btn">
        ${i("success.another")}
      </button>
    </div>
  `},I=(t,e,s)=>{chrome.storage.local.get(["bgfetch.settings"],n=>{var l,m;const r=n["bgfetch.settings"]??{enabled:!0},a=S(),o=F();t.innerHTML=`
      <div class="settings-container">
        <div class="settings-header">
          <button id="btn-settings-back" class="settings-header__back">&larr;</button>
          <h2 class="settings-header__title">${i("settings.title")}</h2>
        </div>

        <div class="settings-section">
          <h3 class="settings-section__title">${i("settings.language")}</h3>
          <div class="settings-lang-switcher">
            <button class="settings-lang-btn ${a==="en"?"settings-lang-btn--active":""}" data-lang="en">EN</button>
            <button class="settings-lang-btn ${a==="ko"?"settings-lang-btn--active":""}" data-lang="ko">KO</button>
          </div>
        </div>

        <div class="settings-divider"></div>

        <div class="settings-section">
          <h3 class="settings-section__title">${i("settings.theme")}</h3>
          <div class="settings-lang-switcher">
            <button class="settings-lang-btn settings-theme-btn ${o==="light"?"settings-lang-btn--active":""}" data-theme="light">☀️ ${i("settings.theme.light")}</button>
            <button class="settings-lang-btn settings-theme-btn ${o==="dark"?"settings-lang-btn--active":""}" data-theme="dark">🌙 ${i("settings.theme.dark")}</button>
          </div>
        </div>

        <div class="settings-divider"></div>

        <div class="settings-section">
          <h3 class="settings-section__title">${i("settings.bgfetch.title")}</h3>

          <label class="settings-toggle-row">
            <span class="toggle-switch">
              <input type="checkbox" id="bgfetch-toggle" ${r.enabled?"checked":""} />
              <span class="toggle-switch__slider"></span>
            </span>
            <span class="settings-toggle-row__label">${i("settings.bgfetch.toggle")}</span>
          </label>

          <p class="settings-hint">${i("settings.bgfetch.hint1")}</p>
          <p class="settings-hint" style="margin-top:4px">${i("settings.bgfetch.hint2")}</p>
          <p class="settings-hint settings-hint--info" style="margin-top:4px">${i("settings.bgfetch.hint3")}</p>
        </div>
      </div>
    `,(l=t.querySelector("#btn-settings-back"))==null||l.addEventListener("click",e),t.querySelectorAll(".settings-lang-btn").forEach(v=>{v.addEventListener("click",()=>{const p=v.dataset.lang;p!==S()&&(te(p),I(t,e,s),s==null||s())})}),t.querySelectorAll(".settings-theme-btn").forEach(v=>{v.addEventListener("click",()=>{const p=v.dataset.theme;p!==F()&&(ne(p),I(t,e,s))})});const u=()=>{const v=t.querySelector("#bgfetch-toggle");chrome.storage.local.set({"bgfetch.settings":{enabled:(v==null?void 0:v.checked)??!1}})};(m=t.querySelector("#bgfetch-toggle"))==null||m.addEventListener("change",u)})},c={loading:document.getElementById("view-loading"),login:document.getElementById("view-login"),form:document.getElementById("view-form"),preview:document.getElementById("view-preview"),sending:document.getElementById("view-sending"),success:document.getElementById("view-success"),settings:document.getElementById("view-settings")},d=t=>{for(const[e,s]of Object.entries(c))s&&s.classList.toggle("view--active",e===t)},N=t=>{const e=document.getElementById("user-avatar");e&&(t!=null&&t.avatar_url?(e.src=t.avatar_url,e.alt=t.name,e.classList.remove("hidden")):e.classList.add("hidden"))},he=1e4,H=t=>new Promise(e=>{const s=setTimeout(()=>{e({success:!1,error:"Service worker not responding. Try again."})},he);try{chrome.runtime.sendMessage(t,n=>{if(clearTimeout(s),chrome.runtime.lastError){e({success:!1,error:chrome.runtime.lastError.message??"Connection lost"});return}e(n??{success:!1,error:"No response from background"})})}catch{clearTimeout(s),e({success:!1,error:"Failed to connect to background"})}}),V={NOT_AMAZON:{title:"error.not_amazon.title",desc:"error.not_amazon.desc",icon:"🌐"},NOT_PRODUCT_PAGE:{title:"error.not_product.title",desc:"error.not_product.desc",icon:"🔍"},PARSE_FAILED:{title:"error.parse.title",desc:"error.parse.desc",icon:"⚠️"},NO_TAB:{title:"error.no_tab.title",desc:"error.no_tab.desc",icon:"📑"},CONNECTION_ERROR:{title:"error.connection.title",desc:"error.connection.desc",icon:"🔌"}},E=(t,e)=>{const s=e.startsWith("PARSE_FAILED")?"PARSE_FAILED":e,n=V[s]??V.PARSE_FAILED,r=e.startsWith("PARSE_FAILED:")?e.substring(13):"";t.innerHTML=`
    <div class="status-message error-view">
      <div class="error-view__icon">${n.icon}</div>
      <h2 class="status-message__title">${i(n.title)}</h2>
      <p class="status-message__desc">${i(n.desc)}</p>
      ${r?`<p class="status-message__desc" style="font-size:11px;color:var(--text-muted);word-break:break-all;margin-top:8px">${r}</p>`:""}
    </div>
  `},be=t=>{d("sending"),ve(c.sending);const e=setTimeout(()=>{d("form"),E(c.form,"CONNECTION_ERROR")},15e3);try{chrome.runtime.sendMessage({type:"QUEUE_REPORT",payload:{page_data:t.pageData,violation_type:t.violationType,violation_category:t.violationCategory,note:t.note,screenshot_base64:t.screenshotBase64}},s=>{var n,r;if(clearTimeout(e),chrome.runtime.lastError){d("form"),E(c.form,"CONNECTION_ERROR");return}if(s!=null&&s.success){d("success"),me(c.success,s.data.report_id,s.data.is_duplicate);const a=c.success.querySelector("#btn-new-report");a==null||a.addEventListener("click",()=>$())}else{if(((n=s==null?void 0:s.error)==null?void 0:n.toLowerCase().includes("session expired"))||((r=s==null?void 0:s.error)==null?void 0:r.toLowerCase().includes("not authenticated"))){N(null),d("login"),z(c.login,()=>$(),"session_expired");return}d("form");const o=c.form.querySelector("#form-error");o&&(o.textContent=(s==null?void 0:s.error)??i("form.error.submit"),o.classList.remove("hidden"))}})}catch{clearTimeout(e),d("form"),E(c.form,"CONNECTION_ERROR")}},$=async()=>{var t;try{d("loading"),oe(c.loading);const e=await H({type:"GET_AUTH_STATUS"});if(!e.success||!((t=e.data)!=null&&t.authenticated)){N(null),d("login"),z(c.login,()=>$());return}N(e.data.user);const s=await H({type:"GET_PAGE_DATA_FROM_TAB"});if(!s.success||!s.data){d("form"),E(c.form,(s.success?null:s.error)??"PARSE_FAILED");return}d("form"),ge(c.form,s.data,n=>{d("preview"),ue(c.preview,n,()=>be(n),()=>{d("form")})})}catch{d("form"),E(c.form,"CONNECTION_ERROR")}};let x="form";const A=document.getElementById("btn-settings");A==null||A.addEventListener("click",()=>{var e;if((e=c.settings)==null?void 0:e.classList.contains("view--active"))d(x);else{for(const[s,n]of Object.entries(c))if(n!=null&&n.classList.contains("view--active")&&s!=="settings"){x=s;break}d("settings"),I(c.settings,()=>{d(x)},()=>{$()})}});const T=document.getElementById("bgfetch-banner"),U=()=>{chrome.storage.local.get("bgfetch.status",t=>{const e=t["bgfetch.status"];T&&(e!=null&&e.active&&e.asin?(T.textContent=`${i("bgfetch.banner")}: ${e.asin} (${e.marketplace??"US"})`,T.classList.remove("hidden")):T.classList.add("hidden"))})};U();chrome.storage.onChanged.addListener(t=>{t["bgfetch.status"]&&U()});Promise.all([se(),ie()]).then(()=>$());
