import"./chunks/modulepreload-polyfill.js";import{V as O,a as M,b as B,W as q}from"./chunks/constants.js";const P=t=>{t.innerHTML=`
    <div class="status-message loading-view">
      <div class="loading-view__spinner"></div>
      <p class="status-message__desc">Loading...</p>
    </div>
  `},F=`
  <svg class="login-logo" viewBox="0 0 24.8 28" fill="#F97316" xmlns="http://www.w3.org/2000/svg">
    <path d="M14,0c2.6,0,4.6,2.1,4.6,4.7S16.5,9.3,14,9.3c-2.6,0-4.7,2.1-4.7,4.7s2,4.8,4.7,4.8s4.6,2.1,4.6,4.6c0,2.6-2.1,4.6-4.6,4.6c-2.6,0-4.7-2.1-4.7-4.6c0-2.6-2.1-4.6-4.6-4.6l0,0c-2.6,0-4.6-2.1-4.6-4.7s2.1-4.6,4.7-4.6l0,0c2.6,0,4.6-2.1,4.6-4.7C9.3,2.1,11.4,0,14,0z"/>
    <path d="M21,10.2c2.1,0,3.8,1.7,3.8,3.7c0,2.1-1.7,3.8-3.8,3.8s-3.7-1.7-3.7-3.8C17.2,11.9,18.9,10.2,21,10.2z"/>
  </svg>
`,A=`
  <svg width="18" height="18" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
    <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 01-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#4285F4"/>
    <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.26c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z" fill="#34A853"/>
    <path d="M3.964 10.71A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.042l3.007-2.332z" fill="#FBBC05"/>
    <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335"/>
  </svg>
`,$=(t,e,s)=>{const n=s==="session_expired"?"Your session has expired. Please sign in again to continue.":"Sign in with your Spigen Google account to report violations.";t.innerHTML=`
    <div class="login-container">
      ${F}
      <h1 class="login-title">Sentinel</h1>
      <p class="login-desc">${n}</p>
      <button id="btn-google-login" class="btn btn--ghost login-btn">
        ${A}
        Sign in with Google
      </button>
      <div id="login-error" class="error-text hidden"></div>
    </div>
  `;const i=t.querySelector("#btn-google-login"),o=t.querySelector("#login-error");i.addEventListener("click",async()=>{i.disabled=!0,i.innerHTML='<span class="spinner"></span> Signing in...',o.classList.add("hidden"),chrome.runtime.sendMessage({type:"SIGN_IN"},a=>{a!=null&&a.success?e():(o.textContent=(a==null?void 0:a.error)??"Sign in failed",o.classList.remove("hidden"),i.disabled=!1,i.innerHTML=`${A} Sign in with Google`)})})},V=(t,e)=>{t.innerHTML=`
    <div class="form-group">
      <label class="form-label form-label--required">Violation Type</label>
      <select id="select-category" class="form-select">
        <option value="">Select Category</option>
        ${Object.entries(O).map(([i,o])=>`<option value="${i}">${o}</option>`).join("")}
      </select>
      <select id="select-violation" class="form-select" disabled>
        <option value="">Select Violation Type</option>
      </select>
    </div>
  `;const s=t.querySelector("#select-category"),n=t.querySelector("#select-violation");s.addEventListener("change",()=>{const i=s.value;if(!i){n.innerHTML='<option value="">Select Violation Type</option>',n.disabled=!0,e(null,null);return}const o=M[i]??[];n.innerHTML=`
      <option value="">Select Violation Type</option>
      ${o.map(a=>`<option value="${a.code}">${a.code} — ${a.name}</option>`).join("")}
    `,n.disabled=!1,n.value="",e(null,i)}),n.addEventListener("change",()=>{const i=n.value,o=s.value;e(i||null,o||null)})},H=(t,e)=>{t.innerHTML=`
    <div class="form-group">
      <label class="form-label">Note (optional)</label>
      <textarea
        id="note-input"
        class="form-textarea"
        placeholder="Describe the violation..."
        rows="4"
        maxlength="2000"
      ></textarea>
    </div>
  `;const s=t.querySelector("#note-input");s.addEventListener("input",()=>{e(s.value)})},N=`
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
  </svg>
`,D=(t,e)=>{t.innerHTML=`
    <button id="btn-submit" class="btn btn--primary" disabled>
      ${N}
      Submit Report
    </button>
    <p class="hint-text">Screenshot will be captured automatically.</p>
  `,t.querySelector("#btn-submit").addEventListener("click",e)},G=t=>{const e=document.querySelector("#btn-submit");e&&(e.disabled=!t)},k=t=>{const e=document.querySelector("#btn-submit");e&&(t?(e.disabled=!0,e.innerHTML='<span class="spinner"></span> Submitting...'):(e.disabled=!1,e.innerHTML=`${N} Submit Report`))},u=t=>{const e=document.createElement("div");return e.textContent=t,e.innerHTML},U=(t,e,s)=>{const n={violationType:null,violationCategory:null,note:""},i=u(e.marketplace);t.innerHTML=`
    <div class="popup-content">
      <div class="product-info">
        <span class="product-info__asin">${u(e.asin)}</span>
        <p class="product-info__title">${u(e.title)}</p>
        ${e.seller_name?`<span class="product-info__seller">Seller: ${u(e.seller_name)}</span>`:""}
        <span class="product-info__marketplace">${i}</span>
      </div>
      <div id="violation-selector"></div>
      <div id="note-input"></div>
      <div id="submit-area"></div>
      <div id="form-error" class="error-text hidden"></div>
    </div>
  `;const o=t.querySelector("#violation-selector"),a=t.querySelector("#note-input"),p=t.querySelector("#submit-area"),m=t.querySelector("#form-error"),g=()=>{G(n.violationType!==null)};V(o,(r,v)=>{n.violationType=r,n.violationCategory=v,g()}),H(a,r=>{n.note=r}),D(p,async()=>{if(!n.violationType||!n.violationCategory)return;k(!0),m.classList.add("hidden");const r=await new Promise(d=>{chrome.runtime.sendMessage({type:"CAPTURE_SCREENSHOT"},d)}),v=r.success?r.data:"";k(!1),s({pageData:e,violationType:n.violationType,violationCategory:n.violationCategory,note:n.note,screenshotBase64:v})})},h=3,C=188.5,z=(t,e,s,n)=>{const i=B[e.violationType],o=O[e.violationCategory];t.innerHTML=`
    <div class="preview-container">
      <h2 class="preview-header">Report Preview</h2>

      <div class="preview-card">
        <div class="preview-card__row">
          <span class="preview-card__label">ASIN</span>
          <span class="preview-card__value preview-card__value--accent">${u(e.pageData.asin)}</span>
        </div>
        <div class="preview-card__row">
          <span class="preview-card__label">Product</span>
          <span class="preview-card__value preview-card__value--title">${u(e.pageData.title)}</span>
        </div>
        <div class="preview-card__row">
          <span class="preview-card__label">Marketplace</span>
          <span class="preview-card__value">${u(e.pageData.marketplace)}</span>
        </div>
        <div class="preview-card__row">
          <span class="preview-card__label">Category</span>
          <span class="preview-card__value">${u(o)}</span>
        </div>
        <div class="preview-card__row">
          <span class="preview-card__label">Violation</span>
          <span class="preview-card__value">${u(i.code)} &mdash; ${u(i.nameEn)}</span>
        </div>
        ${e.note?`
        <div class="preview-card__row">
          <span class="preview-card__label">Note</span>
          <span class="preview-card__value preview-card__value--note">${u(e.note)}</span>
        </div>
        `:""}
        <div class="preview-card__row">
          <span class="preview-card__label">Screenshot</span>
          <span class="preview-card__value preview-card__value--muted">Auto-attached</span>
        </div>
      </div>

      <div class="countdown-area">
        <svg class="countdown-ring" viewBox="0 0 64 64">
          <circle class="countdown-ring__bg" cx="32" cy="32" r="30" fill="none" stroke="#44403C" stroke-width="3" />
          <circle id="countdown-circle" class="countdown-ring__circle" cx="32" cy="32" r="30" fill="none" stroke="#F97316" stroke-width="3"
            stroke-dasharray="${C}" stroke-dashoffset="0"
            stroke-linecap="round" />
          <text id="countdown-text" class="countdown-ring__text" x="32" y="36" text-anchor="middle" fill="#FAFAF9" font-size="16" font-weight="600">${h}</text>
        </svg>
        <p class="countdown-label">Sending automatically...</p>
      </div>

      <button id="btn-preview-cancel" class="btn btn--ghost">Cancel</button>
    </div>
  `;const a=t.querySelector("#countdown-circle"),p=t.querySelector("#countdown-text"),m=t.querySelector("#btn-preview-cancel");let g=0,r=!1;chrome.runtime.sendMessage({type:"PREPARE_REPORT",payload:{page_data:e.pageData,violation_type:e.violationType,violation_category:e.violationCategory,note:e.note,screenshot_base64:e.screenshotBase64}});const v=setInterval(()=>{if(r)return;g+=100;const d=g/(h*1e3);a.setAttribute("stroke-dashoffset",String(C*d));const _=Math.ceil((h*1e3-g)/1e3);p.textContent=String(_),g>=h*1e3&&(clearInterval(v),s())},100);m.addEventListener("click",()=>{r=!0,clearInterval(v);try{chrome.storage.session.remove("pending_report")}catch{}n()}),window.addEventListener("beforeunload",()=>{if(!r&&g<h*1e3)try{chrome.runtime.sendMessage({type:"CONFIRM_REPORT"})}catch{}})},j=t=>{t.innerHTML=`
    <div class="status-message sending-view">
      <div class="sending-view__spinner"></div>
      <h2 class="status-message__title">Sending Report...</h2>
      <p class="status-message__desc">You can close this popup safely.<br/>The report will be sent in the background.</p>
    </div>
  `},W=`
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>
`,Y=(t,e,s=!1)=>{const n=`${q}/reports/${e}`;t.innerHTML=`
    <div class="status-message success-view">
      <div class="success-check success-check--animated">
        ${W}
      </div>
      <h2 class="status-message__title">Report Submitted!</h2>
      ${s?`
        <p class="status-message__desc status-message__desc--warn">
          A similar report already exists for this listing. Your report has been recorded for reference.
        </p>
      `:`
        <p class="status-message__desc">
          Your violation report has been submitted successfully. The team will review it shortly.
        </p>
      `}
      <a href="${n}" target="_blank" rel="noopener" class="btn btn--ghost success-view__btn">
        View in Sentinel
      </a>
      <button id="btn-new-report" class="btn btn--primary success-view__btn">
        Report Another
      </button>
    </div>
  `},K={autoSubmitEnabled:!1,countdownSeconds:3,minDelaySec:30},Q=(t,e)=>{chrome.storage.local.get(["sc_auto_settings","bgfetch.settings"],s=>{var p,m,g,r,v;const n=s.sc_auto_settings??K,i=s["bgfetch.settings"]??{enabled:!0};t.innerHTML=`
      <div class="settings-container">
        <div class="settings-header">
          <button id="btn-settings-back" class="settings-header__back">&larr;</button>
          <h2 class="settings-header__title">Settings</h2>
        </div>

        <div class="settings-section">
          <h3 class="settings-section__title">SC Auto Submit</h3>

          <label class="settings-toggle-row">
            <input type="checkbox" id="auto-submit-toggle" ${n.autoSubmitEnabled?"checked":""} />
            <span class="settings-toggle-row__label">Enable Auto Submit</span>
          </label>

          <div class="settings-field">
            <label class="settings-field__label">Countdown (seconds)</label>
            <select id="countdown-select" class="settings-field__select">
              <option value="3" ${n.countdownSeconds===3?"selected":""}>3 seconds</option>
              <option value="5" ${n.countdownSeconds===5?"selected":""}>5 seconds</option>
              <option value="10" ${n.countdownSeconds===10?"selected":""}>10 seconds</option>
            </select>
          </div>

          <div class="settings-field">
            <label class="settings-field__label">Batch Delay</label>
            <select id="delay-select" class="settings-field__select">
              <option value="30" ${n.minDelaySec===30?"selected":""}>30~60s</option>
              <option value="60" ${n.minDelaySec===60?"selected":""}>60~90s</option>
              <option value="90" ${n.minDelaySec===90?"selected":""}>90~120s</option>
            </select>
          </div>

          <p class="settings-hint">
            Auto submit also requires Admin to enable it in Sentinel Web Settings.
          </p>
        </div>

        <div class="settings-divider"></div>

        <div class="settings-section">
          <h3 class="settings-section__title">Background ASIN Fetch</h3>

          <label class="settings-toggle-row">
            <input type="checkbox" id="bgfetch-toggle" ${i.enabled?"checked":""} />
            <span class="settings-toggle-row__label">Enable Background Fetch</span>
          </label>

          <p class="settings-hint">
            Sentinel automatically looks up ASINs in the background when requested from the web dashboard. A new tab opens briefly (~3s), collects product info, and closes automatically.
          </p>
          <p class="settings-hint" style="margin-top:4px">
            Your existing Amazon session is used. No additional login required.
          </p>
          <p class="settings-hint" style="margin-top:4px; color: var(--accent, #3b82f6);">
            ℹ️ Background Fetch is enabled by default.
          </p>
        </div>
      </div>
    `,(p=t.querySelector("#btn-settings-back"))==null||p.addEventListener("click",e);const o=()=>{const d=t.querySelector("#auto-submit-toggle"),_=t.querySelector("#countdown-select"),f=t.querySelector("#delay-select"),L=Number((f==null?void 0:f.value)??30);chrome.storage.local.set({sc_auto_settings:{autoSubmitEnabled:(d==null?void 0:d.checked)??!1,countdownSeconds:Number((_==null?void 0:_.value)??3),minDelaySec:L,maxDelaySec:L+30}})},a=()=>{const d=t.querySelector("#bgfetch-toggle");chrome.storage.local.set({"bgfetch.settings":{enabled:(d==null?void 0:d.checked)??!1}})};(m=t.querySelector("#auto-submit-toggle"))==null||m.addEventListener("change",o),(g=t.querySelector("#countdown-select"))==null||g.addEventListener("change",o),(r=t.querySelector("#delay-select"))==null||r.addEventListener("change",o),(v=t.querySelector("#bgfetch-toggle"))==null||v.addEventListener("change",a)})},c={loading:document.getElementById("view-loading"),login:document.getElementById("view-login"),form:document.getElementById("view-form"),preview:document.getElementById("view-preview"),sending:document.getElementById("view-sending"),success:document.getElementById("view-success"),settings:document.getElementById("view-settings")},l=t=>{for(const[e,s]of Object.entries(c))s&&s.classList.toggle("view--active",e===t)},T=t=>{const e=document.getElementById("user-avatar");e&&(t!=null&&t.avatar_url?(e.src=t.avatar_url,e.alt=t.name,e.classList.remove("hidden")):e.classList.add("hidden"))},Z=1e4,R=t=>new Promise(e=>{const s=setTimeout(()=>{e({success:!1,error:"Service worker not responding. Try again."})},Z);try{chrome.runtime.sendMessage(t,n=>{if(clearTimeout(s),chrome.runtime.lastError){e({success:!1,error:chrome.runtime.lastError.message??"Connection lost"});return}e(n??{success:!1,error:"No response from background"})})}catch{clearTimeout(s),e({success:!1,error:"Failed to connect to background"})}}),x={NOT_AMAZON:{title:"Not an Amazon Page",desc:"Open an Amazon product page to report a violation.",icon:"🌐"},NOT_PRODUCT_PAGE:{title:"Not a Product Page",desc:"Navigate to an individual product page (with /dp/ in the URL). Search and category pages are not supported.",icon:"🔍"},PARSE_FAILED:{title:"Could Not Read Page",desc:"Failed to extract product data. Try refreshing the page.",icon:"⚠️"},NO_TAB:{title:"No Active Tab",desc:"Could not detect the current tab. Try clicking the extension icon again.",icon:"📑"},CONNECTION_ERROR:{title:"Connection Error",desc:"Could not connect to the extension background. Try reloading the extension.",icon:"🔌"}},b=(t,e)=>{const s=e.startsWith("PARSE_FAILED")?"PARSE_FAILED":e,n=x[s]??x.PARSE_FAILED,i=e.startsWith("PARSE_FAILED:")?e.substring(13):"";t.innerHTML=`
    <div class="status-message error-view">
      <div class="error-view__icon">${n.icon}</div>
      <h2 class="status-message__title">${n.title}</h2>
      <p class="status-message__desc">${n.desc}</p>
      ${i?`<p class="status-message__desc" style="font-size:11px;color:var(--text-muted);word-break:break-all;margin-top:8px">${i}</p>`:""}
    </div>
  `},J=t=>{l("sending"),j(c.sending);const e=setTimeout(()=>{l("form"),b(c.form,"CONNECTION_ERROR")},15e3);try{chrome.runtime.sendMessage({type:"QUEUE_REPORT",payload:{page_data:t.pageData,violation_type:t.violationType,violation_category:t.violationCategory,note:t.note,screenshot_base64:t.screenshotBase64}},s=>{var n,i;if(clearTimeout(e),chrome.runtime.lastError){l("form"),b(c.form,"CONNECTION_ERROR");return}if(s!=null&&s.success){l("success"),Y(c.success,s.data.report_id,s.data.is_duplicate);const o=c.success.querySelector("#btn-new-report");o==null||o.addEventListener("click",()=>y())}else{if(((n=s==null?void 0:s.error)==null?void 0:n.toLowerCase().includes("session expired"))||((i=s==null?void 0:s.error)==null?void 0:i.toLowerCase().includes("not authenticated"))){T(null),l("login"),$(c.login,()=>y(),"session_expired");return}l("form");const a=c.form.querySelector("#form-error");a&&(a.textContent=(s==null?void 0:s.error)??"Submission failed. Please try again.",a.classList.remove("hidden"))}})}catch{clearTimeout(e),l("form"),b(c.form,"CONNECTION_ERROR")}},y=async()=>{var t;try{l("loading"),P(c.loading);const e=await R({type:"GET_AUTH_STATUS"});if(!e.success||!((t=e.data)!=null&&t.authenticated)){T(null),l("login"),$(c.login,()=>y());return}T(e.data.user);const s=await R({type:"GET_PAGE_DATA_FROM_TAB"});if(!s.success||!s.data){l("form"),b(c.form,s.error??"PARSE_FAILED");return}l("form"),U(c.form,s.data,n=>{l("preview"),z(c.preview,n,()=>J(n),()=>{l("form")})})}catch{l("form"),b(c.form,"CONNECTION_ERROR")}};let S="form";const E=document.getElementById("btn-settings");E==null||E.addEventListener("click",()=>{var e;if((e=c.settings)==null?void 0:e.classList.contains("view--active"))l(S);else{for(const[s,n]of Object.entries(c))if(n!=null&&n.classList.contains("view--active")&&s!=="settings"){S=s;break}l("settings"),Q(c.settings,()=>{l(S)})}});const w=document.getElementById("bgfetch-banner"),I=()=>{chrome.storage.local.get("bgfetch.status",t=>{const e=t["bgfetch.status"];w&&(e!=null&&e.active&&e.asin?(w.textContent=`Background Fetch: ${e.asin} (${e.marketplace??"US"})`,w.classList.remove("hidden")):w.classList.add("hidden"))})};I();chrome.storage.onChanged.addListener(t=>{t["bgfetch.status"]&&I()});y();
